/********************************************************************************
 * Program Filename: MazeSearch
 * Author: Andrew Luna
 * Date: November 18, 2016
 * Description: states if the maze is solvable or unsolvable.
 * Input: the location of the maze
 * Output: a statement that states if the maze is solvable.
 ********************************************************************************/
package mazesearch;
public class MazeSearch {  
    public static void main(String[] args) throws InterruptedException {
        Maze labyrinth = new Maze();
        labyrinth.toString();
        if(labyrinth.Traverse(0, 0)) {
            System.out.println("Maze solved.");
        } else {
            System.out.println("Maze is unsolvable.");
        }        
    }
}
