/********************************************************************************
 * Program Filename: MazeSearch.java
 * Author: Luna, Andrew
 * Date: November 19, 2016
 * Description: 
 * Input: 
 * Output: 
 ********************************************************************************/

package mazesearch;
public class Maze{
    //when the path is tried it will print out a 3
    private final int TRIED = 3;
    //when the path is right the system will print a 7
    private final int PATH = 7;
    int[][] grid = {{1,1,1,0,1,1,0,0,0,1,1,1,1},
                   {1,0,1,1,1,0,1,1,1,1,0,0,1},
                   {0,0,0,0,1,0,1,0,1,0,1,0,0},
                   {1,1,1,0,1,1,1,0,1,0,1,1,1},
                   {1,0,1,0,0,0,0,1,1,1,0,0,1},
                   {1,0,1,1,1,1,1,1,0,1,1,1,1},
                   {1,0,0,0,0,0,0,0,0,0,0,0,0},
                   {1,1,1,1,1,1,1,1,1,1,1,1,1}};
    
    /****************************************************************************
     * Method: toString
     * Description: This method prints out the array grid.
     * Parameters: none
     * Pre-Conditions: the array grid
     * Post-Conditions: the array printed out
     ****************************************************************************/
    @Override
    public String toString() {
        System.out.println("");
        for(int row = 0; row < grid.length; row++) {
            for(int col = 0; col < grid[row].length; col++) {
                if(grid[row][col] == PATH) {
                    System.out.print(grid[row][col]);
                } else if(grid[row][col] == TRIED) {
                    System.out.print(grid[row][col]);
                } else {
                    System.out.print(grid[row][col]);
                }
            }
            System.out.println("");
        }
        System.out.println("");
        return null;
    }
    
    /****************************************************************************
     * Method: Traverse
     * Description: This Method checks
     * Parameters: 
     * Pre-Conditions: 
     * Post-Conditions: 
     ****************************************************************************/
    public boolean Traverse(int Row, int Col) throws InterruptedException {
        boolean value = false; 
        if(valid(Row, Col)) {
            grid[Row][Col] = TRIED;
            if(Row == grid.length - 1 && Col == grid[0].length - 1) {
                value = true;
            } else {
                value = Traverse(Row+1, Col);
                if(value == true) {
                    value = Traverse(Row, Col+1);
                }
                 if(value == true) {
                    value = Traverse(Row-1, Col);
                }
                if(value == true) {
                    value = Traverse(Row, Col-1);
                }               
            }
            if(value == false) {
                grid[Row][Col] = PATH;
            }
            for(int lines = 0; lines < 100; lines++) {
                System.out.println("");
            }
        }
        toString();
        Thread.sleep(500);
        return value;
    }
    
    /****************************************************************************
     * Method:
     * Description: 
     * Parameters: 
     * Pre-Conditions: 
     * Post-Conditions: 
     ****************************************************************************/
    private boolean valid(int Row, int Col) throws InterruptedException {
        boolean end = false;
        if(Row >= 0 && Row < grid.length && Col >= 0 && Col < grid[Row].length) {
            if(grid[Row][Col] == 1) {
                end = true;
            }
        }
        for(int skip = 0; skip < 100; skip++) {
            System.out.println("");
        }
        toString();
        Thread.sleep(500);
        toString();
        return end;
    }
}
